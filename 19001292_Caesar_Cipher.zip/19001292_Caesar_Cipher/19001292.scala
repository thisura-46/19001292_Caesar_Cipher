object ceaser extends App{

  val alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"

  def decrypt(x:Char, key:Int, y:String): Char = {
    var ind = y.indexOf(x.toUpper) - key
    if (ind < 0) ind = 26 - Math.abs(ind)
    val res = y(ind)
    return res
  }

  def encrypt(x:Char, key:Int, y:String): Char = {
    val res = y((y.indexOf(x.toUpper) + key) % y.size)
    return res
  }

  def cipher(algo:(Char,Int,String) => Char, z:String, key:Int, y:String): String = {
    val new_z = z.map(algo(_, key, y))
    return new_z
  }

  val ct = cipher(encrypt, "UCSC" , 6, alphabet)
  val pt = cipher(decrypt, ct, 6, alphabet)

  println("\"UCSC\" Encrypted = "+ct)
  println("\""+ ct + "\"" + " Decrypted = "+pt)
}
